INFINITY EMPIRE — PERMANENT REPLIT BASE V3.99

ONE-TIME INSTALL:
- Put these files at the ROOT of your Replit project:
    index.html
    style.css
    game.js
    admin.js
    .replit
    assets/

Then press Run.

AFTER THIS:
- Admin update -> replace admin.js only.
- Interface update -> replace style.css only (or a small override file when supplied).
- Gameplay update -> replace game.js only.
- Images stay in assets/ and normally do not need to be uploaded again.

IMPORTANT:
Do not delete assets/.
Do not paste the full game into index.html.
