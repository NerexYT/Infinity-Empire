/*
 Infinity Empire — ADMIN OVERRIDE FILE
 -------------------------------------
 This file is intentionally separate.

 From the next Admin update onward, replace ONLY this file.
 It loads after game.js, so new Admin code can safely override the base Admin UI/functions.

 Current V3.99 base Admin is already contained in game.js.
*/
